﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using Harmony;
using OneSprinklerOneScarecrow.Framework.Overrides;
using StardewModdingAPI;
using StardewModdingAPI.Events;
using StardewValley;
using StardewValley.Buildings;
using StardewValley.Locations;
using StardewValley.TerrainFeatures;
using Object = StardewValley.Object;
using SObject = StardewValley.Object;

namespace OneSprinklerOneScarecrow
{
    public class ModEntry : Mod
    {
        private AddCrowsPatch addcrows;
        public override void Entry(IModHelper helper)
        {
            helper.Events.GameLoop.DayStarted += OnDayStarted;
            helper.Events.Player.InventoryChanged += InventoryChanged;


            //Apply Harmony Patches
            var harmony = HarmonyInstance.Create(this.ModManifest.UniqueID);
            Monitor.Log("Patching Farm.addCrows with AddCrowsPatch");
            harmony.Patch(
                original: AccessTools.Method(typeof(Farm), nameof(Farm.addCrows), new Type[] {  }),
                prefix: new HarmonyMethod(typeof(AddCrowsPatch), nameof(AddCrowsPatch.Prefix))
            );

            Monitor.Log("Patching Object.IsSprinkler with IsSprinklerPatch");
            harmony.Patch(
                original: AccessTools.Method(typeof(Object), nameof(Object.IsSprinkler), new Type[] {  }),
                prefix: new HarmonyMethod(typeof(IsSprinklerPatch), nameof(IsSprinklerPatch.Prefix))
            );

            Monitor.Log("Patching Object.GetBaseRadiusForSprinkler with GetBaseRadiusForSprinklerPatch");
            harmony.Patch(
                original: AccessTools.Method(typeof(Object), nameof(Object.GetBaseRadiusForSprinkler), new Type[] { }),
                prefix: new HarmonyMethod(typeof(GetBaseRadiusForSprinklerPatch), nameof(GetBaseRadiusForSprinklerPatch.Prefix))
            );

        }

        /// <summary>
        /// Event that runs when a new day is started
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">The EventArgs</param>
        private void OnDayStarted(object sender, DayStartedEventArgs e)
        {
            //Make sure the game is loaded
            if (!Context.IsWorldReady)
                return;

            //Go through each location and modify the sprinklers.
            foreach (var loc in GetLocations())
            {
                foreach (SObject obj in loc.Objects.Values)
                {
                    if (obj.Name == "Haxor Sprinkler")
                    {
                        //go through and and do the watering
                        foreach (var waterSpots in loc.terrainFeatures.Pairs)
                        {
                            if (waterSpots.Value is HoeDirt dirt)
                                dirt.state.Value = HoeDirt.watered;
                        }
                    }
                }
            }
        }

        private void InventoryChanged(object sender, InventoryChangedEventArgs e)
        {
            
            if (e.Added.First().Name.Contains("Haxor Sprinkler"))
            {
                SObject i = new SObject(e.Added.First().ParentSheetIndex, e.Added.First().Stack);
                Monitor.Log($"Found a new Haxor Sprinkler: {i.Name}.");
                i.CanBeSetDown = true;
                i.Type = "Crafting";
            }
        }
        /// <summary>Get all in-game locations.</summary>
        private IEnumerable<GameLocation> GetLocations()
        {
            foreach (GameLocation location in Game1.locations)
            {
                yield return location;
                if (location is BuildableGameLocation buildableLocation)
                {
                    foreach (Building building in buildableLocation.buildings)
                    {
                        if (building.indoors.Value != null)
                            yield return building.indoors.Value;
                    }
                }
            }
        }
    }
}
