#nullable enable
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using BankOfFerngill.Framework.Menu.Components;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using StardewModdingAPI;
using StardewValley;
using StardewValley.Menus;

namespace BankOfFerngill.Framework.Menu
{
    internal class BankMenu1 : IClickableMenu
    {
        /*
         * This menu is based on the CheatMenu from CJB Cheat Menu which can be found at https://github.com/CJBok/SDV-Mods/tree/5f96066858f230d2396540457e352ecc8660287c/CJBCheatsMenu.
         * Credit goes to the authors of that mod.
         */
        
        
        private readonly IMonitor Monitor;
        private readonly IModHelper _helper;
        private readonly ITranslationHelper _i18N;
        public const int ButtonBorderWidth = 4 * Game1.pixelZoom;
        
        private readonly List<ClickableComponent> OptionSlots = new();
        private readonly List<OptionsElement> Options = new();
        private readonly List<OptionsElement> _bankOptions = new();
        private ClickableTextureComponent UpArrow, DownArrow, ScrollBar;
        private ClickableComponent _bankTitle;
        private TextBox _textBox;
        private TextBoxEvent _tbEvent;
        private readonly List<ClickableComponent> Tabs = new();
        private const int ItemsPerPageShown = 10;

        private readonly bool IsAndroid = Constants.TargetPlatform == GamePlatform.Android;
        private string HoverText = "";
        private bool _justOpened = true;
        private int OptionsSlotHeld = -1;
        private int CurrentItemIndex = -1;
        private bool IsScrolling;
        private Rectangle ScrollbarRunner;

        private bool JustOpened = true;
        
        //Now we make the menu happen
        
        public MenuTabs CurrentTab { get; }

        public BankMenu1(MenuTabs initialTab, IMonitor monitor, IModHelper helper, ITranslationHelper i18n, bool isNewMenu)
        {
            Monitor = monitor;
            _helper = helper;
            _i18N = i18n;
            CurrentTab = initialTab;
            ResetComponents();
            SetOptions();

            ResetComponents();
        }

        public void ExitIfValid()
        {
            if (readyToClose() && !GameMenu.forcePreventClose)
            {
                Game1.exitActiveMenu();
            }
        }

        public override bool overrideSnappyMenuCursorMovementBan()
        {
            return true;
        }

        public override void gameWindowSizeChanged(Rectangle oldBounds, Rectangle newBounds)
        {
           ResetComponents();
        }

        public override void leftClickHeld(int x, int y)
        {
            if (GameMenu.forcePreventClose)
                return;
            base.leftClickHeld(x,y);
            if(IsScrolling)
            {

                int num = ScrollBar.bounds.Y;
                ScrollBar.bounds.Y = Math.Min(yPositionOnScreen + height - Game1.tileSize - Game1.pixelZoom * 3 - ScrollBar.bounds.Height, Math.Max(y, yPositionOnScreen + UpArrow.bounds.Height + Game1.pixelZoom * 5));
                CurrentItemIndex = Math.Min(Options.Count - ItemsPerPageShown, Math.Max(0, (int)Math.Round((Options.Count - ItemsPerPageShown) * (double)((y - ScrollbarRunner.Y) / (float)ScrollbarRunner.Height))));
                SetScrollBarToCurrentIndex();
                if (num == ScrollBar.bounds.Y)
                    return;
                
            }
            else
            {
                if (OptionsSlotHeld == -1 || OptionsSlotHeld + CurrentItemIndex >= Options.Count)
                    return;
                Options[CurrentItemIndex + OptionsSlotHeld].leftClickHeld(x - OptionSlots[OptionsSlotHeld].bounds.X, y - OptionSlots[OptionsSlotHeld].bounds.Y);
            }
        }

        public override void receiveKeyPress(Keys key)
        {
            // exit menu
            if (((IList)Game1.options.menuButton).Contains(new InputButton(key)) && !IsPressNewKeyActive())
                ExitIfValid();

            // send key to active option
            else
                GetActiveOption()?.receiveKeyPress(key);
        }

        public override void receiveScrollWheelAction(int direction)
        {
            if (GameMenu.forcePreventClose)
                return;
            base.receiveScrollWheelAction(direction);
            if (direction > 0 && CurrentItemIndex > 0)
                UpArrowPressed();
            else
            {
                if (direction >= 0 || CurrentItemIndex >= Math.Max(0, this.Options.Count - ItemsPerPageShown))
                    return;
                DownArrowPressed();
            }
        }
        
        public override void releaseLeftClick(int x, int y)
        {
            if (GameMenu.forcePreventClose)
                return;
            base.releaseLeftClick(x, y);
            if (OptionsSlotHeld != -1 && OptionsSlotHeld + CurrentItemIndex < Options.Count)
                Options[CurrentItemIndex + OptionsSlotHeld].leftClickReleased(x - OptionSlots[OptionsSlotHeld].bounds.X, y - OptionSlots[OptionsSlotHeld].bounds.Y);
            OptionsSlotHeld = -1;
            IsScrolling = false;
        }

        public override void receiveLeftClick(int x, int y, bool playSound = true)
        {
            if (GameMenu.forcePreventClose)
                return;
            base.receiveLeftClick(x, y, playSound);

            if (DownArrow.containsPoint(x, y) && CurrentItemIndex < Math.Max(0, Options.Count - ItemsPerPageShown))
            {
                DownArrowPressed();
            }
            else if (UpArrow.containsPoint(x, y) && CurrentItemIndex > 0)
            {
                UpArrowPressed();
            }
            else if (ScrollBar.containsPoint(x, y))
                IsScrolling = true;
            else if (!DownArrow.containsPoint(x, y) && x > xPositionOnScreen + width && (x < xPositionOnScreen + width + Game1.tileSize * 2 && y > yPositionOnScreen) && y < yPositionOnScreen + height)
            {
                IsScrolling = true;
                leftClickHeld(x, y);
                releaseLeftClick(x, y);
            }
            CurrentItemIndex = Math.Max(0, Math.Min(_bankOptions.Count - ItemsPerPageShown, CurrentItemIndex));
            for (int index = 0; index < OptionSlots.Count; ++index)
            {
                if (OptionSlots[index].bounds.Contains(x, y) && CurrentItemIndex + index < Options.Count && Options[CurrentItemIndex + index].bounds.Contains(x - OptionSlots[index].bounds.X, y - OptionSlots[index].bounds.Y - 5))
                {
                    Options[CurrentItemIndex + index].receiveLeftClick(x - OptionSlots[index].bounds.X, y - OptionSlots[index].bounds.Y + 5);
                    OptionsSlotHeld = index;
                    break;
                }
            }

            foreach (ClickableComponent tab in Tabs)
            {
                if (tab.bounds.Contains(x, y))
                {
                    MenuTabs tabID = GetTabID(tab);
                    Game1.activeClickableMenu = new BankMenu1(tabID, Monitor, _helper, _i18N, isNewMenu: false);
                    break;
                }
            }
        }

        public override void performHoverAction(int x, int y)
        {
            if (GameMenu.forcePreventClose)
                return;
            HoverText = "";
            UpArrow.tryHover(x, y);
            DownArrow.tryHover(x, y);
            ScrollBar.tryHover(x, y);
            
        }

        public override void draw(SpriteBatch b)
        {
            if (!Game1.options.showMenuBackground)
                b.Draw(Game1.fadeToBlackRect, Game1.graphics.GraphicsDevice.Viewport.Bounds, Color.Black * 0.4f);
            base.draw(b);

            Game1.drawDialogueBox(xPositionOnScreen, yPositionOnScreen, width, height, false, true);
            DrawTab(_bankTitle.bounds.X, _bankTitle.bounds.Y, Game1.dialogueFont, _bankTitle.name, 1);
            b.End();
            b.Begin(SpriteSortMode.FrontToBack, BlendState.AlphaBlend, SamplerState.PointClamp);
            for (int index = 0; index < OptionSlots.Count; ++index)
            {
                if (CurrentItemIndex >= 0 && CurrentItemIndex + index < Options.Count)
                    Options[CurrentItemIndex + index].draw(b, OptionSlots[index].bounds.X, OptionSlots[index].bounds.Y + 5);
            }
            b.End();
            b.Begin(SpriteSortMode.Deferred, BlendState.AlphaBlend, SamplerState.PointClamp);
            if (!GameMenu.forcePreventClose)
            {
                foreach (ClickableComponent tab in Tabs)
                {
                    MenuTabs tabID = GetTabID(tab);
                    DrawTab(tab.bounds.X + tab.bounds.Width, tab.bounds.Y, Game1.smallFont, tab.label, 2, CurrentTab == tabID ? 1F : 0.7F);
                }

                UpArrow.draw(b);
                DownArrow.draw(b);
                if (Options.Count > ItemsPerPageShown)
                {
                    drawTextureBox(b, Game1.mouseCursors, new Rectangle(403, 383, 6, 6), ScrollbarRunner.X, ScrollbarRunner.Y, ScrollbarRunner.Width, ScrollbarRunner.Height, Color.White, Game1.pixelZoom, false);
                    ScrollBar.draw(b);
                }
            }
            if (HoverText != "")
                drawHoverText(b, HoverText, Game1.smallFont);

            if (!Game1.options.hardwareCursor && !IsAndroid)
                b.Draw(Game1.mouseCursors, new Vector2(Game1.getOldMouseX(), Game1.getOldMouseY()), Game1.getSourceRectForStandardTileSheet(Game1.mouseCursors, Game1.options.gamepadControls ? 44 : 0, 16, 16), Color.White, 0f, Vector2.Zero, Game1.pixelZoom + Game1.dialogueButtonScale / 150f, SpriteEffects.None, 1f);

            // reinitialize the UI to fix Android pinch-zoom scaling issues
            if (JustOpened)
            {
                JustOpened = false;
                if (IsAndroid)
                    ResetComponents();
            }
            
        }
        
        public static void DrawTab(int x, int y, SpriteFont font, string text, int align = 0, float alpha = 1, bool drawShadow = true)
        {
            SpriteBatch spriteBatch = Game1.spriteBatch;
            Vector2 bounds = font.MeasureString(text);

            DrawTab(x, y, (int)bounds.X, (int)bounds.Y, out Vector2 drawPos, align, alpha, drawShadow: drawShadow);
            Utility.drawTextWithShadow(spriteBatch, text, font, drawPos, Game1.textColor);
        }

        public static void DrawTab(int x, int y, int innerWidth, int innerHeight, out Vector2 innerDrawPosition, int align = 0, float alpha = 1, bool drawShadow = true)
        {
            SpriteBatch spriteBatch = Game1.spriteBatch;

            // calculate outer coordinates
            int outerWidth = innerWidth + ButtonBorderWidth * 2;
            int outerHeight = innerHeight + Game1.tileSize / 3;
            int offsetX = align switch
            {
                1 => -outerWidth / 2,
                2 => -outerWidth,
                _ => 0
            };

            // draw texture
            drawTextureBox(spriteBatch, Game1.menuTexture, new Rectangle(0, 256, 60, 60), x + offsetX, y, outerWidth, outerHeight + Game1.tileSize / 16, Color.White * alpha, drawShadow: drawShadow);
            innerDrawPosition = new Vector2(x + ButtonBorderWidth + offsetX, y + ButtonBorderWidth);
        }
        
        private void ResetComponents()
        {
            // set dimensions
            width = (IsAndroid ? 750 : 800) + borderWidth * 2;
            height = (IsAndroid ? 550 : 600) + borderWidth * 2;
            xPositionOnScreen = Game1.uiViewport.Width / 2 - (width - (int)(Game1.tileSize * 2.4f)) / 2;
            yPositionOnScreen = Game1.uiViewport.Height / 2 - height / 2;

            // show close button on Android
            if (IsAndroid)
                initializeUpperRightCloseButton();

            // add title
            _bankTitle = new ClickableComponent(new Rectangle(xPositionOnScreen + width / 2, yPositionOnScreen, Game1.tileSize * 4, Game1.tileSize), _helper.Translation.Get("bank.info.title"));

            // add tabs
            {
                int i = 0;
                int labelX = (int)(xPositionOnScreen - Game1.tileSize * 4.8f);
                int labelY = (int)(yPositionOnScreen + Game1.tileSize * (IsAndroid ? 1.25f : 1.5f));
                int labelHeight = (int)(Game1.tileSize * 0.9F);

                Tabs.Clear();
                Tabs.AddRange(new[]
                {
                    new ClickableComponent(new Rectangle(labelX, labelY + labelHeight * i++, Game1.tileSize * 5, Game1.tileSize), MenuTabs.BankInfo.ToString(), _i18N.Get("bank.menu.bankinfo")),
                    new ClickableComponent(new Rectangle(labelX, labelY + labelHeight * i++, Game1.tileSize * 5, Game1.tileSize), MenuTabs.Deposit.ToString(), _i18N.Get("bank.menu.deposit")),
                    new ClickableComponent(new Rectangle(labelX, labelY + labelHeight * i++, Game1.tileSize * 5, Game1.tileSize), MenuTabs.Withdraw.ToString(), _i18N.Get("bank.menu.withdraw")),
                    new ClickableComponent(new Rectangle(labelX, labelY + labelHeight * i++, Game1.tileSize * 5, Game1.tileSize), MenuTabs.TakeOutLoan.ToString(), _i18N.Get("bank.menu.takeloan")),
                    new ClickableComponent(new Rectangle(labelX, labelY + labelHeight * i++, Game1.tileSize * 5, Game1.tileSize), MenuTabs.PayBackLoan.ToString(), _i18N.Get("bank.menu.payloan"))
                });
            }

            // add scroll UI
            int scrollbarOffset = Game1.tileSize * (IsAndroid ? 1 : 4) / 16;
            UpArrow = new ClickableTextureComponent("up-arrow", new Rectangle(xPositionOnScreen + width + scrollbarOffset, yPositionOnScreen + Game1.tileSize, 11 * Game1.pixelZoom, 12 * Game1.pixelZoom), "", "", Game1.mouseCursors, new Rectangle(421, 459, 11, 12), Game1.pixelZoom);
            DownArrow = new ClickableTextureComponent("down-arrow", new Rectangle(xPositionOnScreen + width + scrollbarOffset, yPositionOnScreen + height - Game1.tileSize, 11 * Game1.pixelZoom, 12 * Game1.pixelZoom), "", "", Game1.mouseCursors, new Rectangle(421, 472, 11, 12), Game1.pixelZoom);
            ScrollBar = new ClickableTextureComponent("scrollbar", new Rectangle(UpArrow.bounds.X + Game1.pixelZoom * 3, UpArrow.bounds.Y + UpArrow.bounds.Height + Game1.pixelZoom, 6 * Game1.pixelZoom, 10 * Game1.pixelZoom), "", "", Game1.mouseCursors, new Rectangle(435, 463, 6, 10), Game1.pixelZoom);
            ScrollbarRunner = new Rectangle(ScrollBar.bounds.X, UpArrow.bounds.Y + UpArrow.bounds.Height + Game1.pixelZoom, ScrollBar.bounds.Width, height - Game1.tileSize * 2 - UpArrow.bounds.Height - Game1.pixelZoom * 2);
            SetScrollBarToCurrentIndex();

            // add option slots
            OptionSlots.Clear();
            for (int i = 0; i < ItemsPerPageShown; i++)
                OptionSlots.Add(new ClickableComponent(new Rectangle(xPositionOnScreen + Game1.tileSize / 4, yPositionOnScreen + Game1.tileSize * 5 / 4 + Game1.pixelZoom + i * ((height - Game1.tileSize * 2) / ItemsPerPageShown), width - Game1.tileSize / 2, (height - Game1.tileSize * 2) / ItemsPerPageShown + Game1.pixelZoom), string.Concat(i)));
        }

        private void SetOptions()
        {
            Options.Clear();

            int slotWidth = OptionSlots[0].bounds.Width;
            switch (CurrentTab)
            {
                case MenuTabs.BankInfo:
                {
                    AddTitle($"{_i18N.Get("bank.menu.bankinfo")}:");
                    AddDescription(_i18N.Get("bank.events.stockRose"));

                    this.AddOptions(
                        new BankOfFerngill.Framework.Menu.Components.BankOptionsButton(
                            label: "",
                            slotWidth: slotWidth,
                            toggle: test
                        
                            )
                        );
                }
                    break;
            }
            SetScrollBarToCurrentIndex();
        }

        private void test()
        {
            
        }
        private bool IsPressNewKeyActive()
        {
            return Options.Any(p => p is BankOptionsKeyListener { IsListening: true });
        }

        private void AddTitle(string title)
        {
            Options.Add(new OptionsElement(title));
        }

        private void AddDescription(string text)
        {
            // get text lines
            int maxWidth = width - Game1.tileSize - 10;

            foreach (string originalLine in text.Replace("\r\n", "\n").Split('\n'))
            {
                string line = "";
                foreach (string word in originalLine.Split(' '))
                {
                    if (line == "")
                        line = word;
                    else if (Game1.smallFont.MeasureString(line + " " + word).X <= maxWidth)
                        line += " " + word;
                    else
                    {
                        Options.Add(new DescriptionElement(line));
                        line = word;
                    }
                }
                if (line != "")
                    Options.Add(new DescriptionElement(line));
            }
        }
        
        
        private OptionsElement? GetActiveOption()
        {
            if (OptionsSlotHeld == -1)
                return null;
            int index = CurrentItemIndex + OptionsSlotHeld;
            return index < Options.Count ? Options[index] : null;
        } 
        private void AddOptions(params OptionsElement[] fields)
        {
            Options.AddRange(fields);
        }

        private void SetScrollBarToCurrentIndex()
        {
            if (!Options.Any())
                return;
            ScrollBar.bounds.Y = ScrollbarRunner.Height / Math.Max(1, Options.Count - ItemsPerPageShown + 1) * CurrentItemIndex + UpArrow.bounds.Bottom + Game1.pixelZoom;
            if (CurrentItemIndex != Options.Count - ItemsPerPageShown)
                return;
            ScrollBar.bounds.Y = DownArrow.bounds.Y - ScrollBar.bounds.Height - Game1.pixelZoom;
        }
        
        private void DownArrowPressed()
        {
            DownArrow.scale = DownArrow.baseScale;
            ++CurrentItemIndex;
            SetScrollBarToCurrentIndex();
        }

        private void UpArrowPressed()
        {
            UpArrow.scale = UpArrow.baseScale;
            --CurrentItemIndex;
            SetScrollBarToCurrentIndex();
        }
        
        private MenuTabs GetTabID(ClickableComponent tab)
        {
            if (!Enum.TryParse(tab.name, out MenuTabs tabID))
                throw new InvalidOperationException($"Couldn't parse tab name '{tab.name}'.");
            return tabID;
        }
    }
    
    //Tab enum
    internal enum MenuTabs
    {
        BankInfo,
        Deposit,
        Withdraw,
        TakeOutLoan,
        PayBackLoan
    }
}