namespace BankOfFerngill.Framework.Menu
{
    internal enum MenuTab
    {
        BankInfo,
        Deposit,
        Withdraw,
        TakeOutLoan,
        PayBackLoan
    }
}