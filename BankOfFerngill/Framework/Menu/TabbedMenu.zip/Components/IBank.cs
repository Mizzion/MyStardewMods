using System.Collections.Generic;
using Microsoft.Xna.Framework.Graphics;
using StardewModdingAPI.Events;
using StardewValley.Menus;

namespace BankOfFerngill.Framework.Menu.Components
{
    internal interface IBank
    {
        IEnumerable<OptionsElement> GetFields(BankContext context);
        
        void OnConfig(BankContext context, out bool needsInput, out bool needsUpdate, out bool needsRendering);

        void OnSaveLoaded(BankContext context);
        
        void OnButtonsChanged(BankContext context, ButtonsChangedEventArgs e);

        void OnUpdated(BankContext context, UpdateTickedEventArgs e);

        void OnRendered(BankContext context, SpriteBatch spriteBatch);
        
    }
}