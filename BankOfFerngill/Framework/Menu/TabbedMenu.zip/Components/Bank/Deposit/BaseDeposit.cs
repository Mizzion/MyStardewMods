namespace BankOfFerngill.Framework.Menu.Components.Bank.Deposit
{
    internal abstract class BaseDeposit : BaseBank
    {
        protected void DoDeposit(string str)
        {
            
        }
    }
}