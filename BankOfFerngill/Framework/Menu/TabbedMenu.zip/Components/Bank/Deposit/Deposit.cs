using System.Collections.Generic;
using StardewValley.Menus;

namespace BankOfFerngill.Framework.Menu.Components.Bank.Deposit
{
    internal class Deposit : BaseDeposit
    {
        public override IEnumerable<OptionsElement> GetFields(BankContext context)
        {
            yield return new BankOptionsTextBox(
                label: "",
                slotWidth: context.SlotWidth,
                doneBehaviour: this.DoDeposit,
                disabled: false
            );
        }
    }
}