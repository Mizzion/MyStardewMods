using System.Collections.Generic;
using StardewValley.Menus;

namespace BankOfFerngill.Framework.Menu.Components.Bank.BanInfo
{
    internal class BankInfo : BaseBank
    {
        public override IEnumerable<OptionsElement> GetFields(BankContext context)
        {
            yield break; // handled by cheats menu directly
        }
    }
}