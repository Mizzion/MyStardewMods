using System;
using Microsoft.Xna.Framework.Graphics;
using StardewValley;
using StardewValley.Menus;

namespace BankOfFerngill.Framework.Menu.Components
{
    internal class BankOptionsTextBox : BaseOptionsElement
    {
        public delegate void DoneBehaviour(string s);
        private readonly ClickableTextureComponent _okButtonCc;
        //private ClickableComponent _textBoxCc;
        private readonly TextBox _textBox;
        private readonly DoneBehaviour _doneBehaviour;
        
        //Lets set up the text box
        /*
        _textBox = new TextBox(null, null, Game1.dialogueFont, Game1.textColor)
        {
            X = _xPos + (UiWidth - 512) / 2,
            Y = _title.bounds.Y + (64 * 6),
            Width = 512,
            Height = 192
        };
    Game1.keyboardDispatcher.Subscriber = _textBox;
    _textBox.OnEnterPressed += TextBoxEnter;
    _textBox.Selected = true;*/

        public BankOptionsTextBox(string label, int slotWidth, DoneBehaviour doneBehaviour, bool disabled)
            : base(label, -1, -1, slotWidth + 1, 11 + Game1.pixelZoom)
        {
            _textBox = new TextBox(null, null, Game1.dialogueFont, Game1.textColor)
            {
                
                Width = 400,
                Height = 192
            };
            Game1.keyboardDispatcher.Subscriber = _textBox;
            _textBox.OnEnterPressed += TextBoxEnter;
            _textBox.Selected = true;
            _doneBehaviour = doneBehaviour;
            
        }

        public override void draw(SpriteBatch b, int slotX, int slotY, IClickableMenu context = null)
        {
            _textBox.Draw(b);
            base.draw(b, slotX + this.GetOffsetX(), slotY, context);
        }

        private void TextBoxEnter(TextBox sender)
        {
            if (sender.Text.Length >= 1)
            {
                if (_doneBehaviour is not null)
                {
                    _doneBehaviour(sender.Text);
                    _textBox.Selected = false;
                }
                else
                {
                    //_monitor.Log("The Ok button was null.");
                }
            }
        }
    }
}