using System;
using System.Collections.Generic;
using System.Linq;
using BankOfFerngill.Framework.Configs;
using BankOfFerngill.Framework.Menu.Components.Bank;
using BankOfFerngill.Framework.Menu.Components.Bank.BanInfo;
using BankOfFerngill.Framework.Menu.Components.Bank.Deposit;
using StardewModdingAPI;
using StardewValley;

namespace BankOfFerngill.Framework.Menu.Components
{
    internal class BankManager
    {
        private readonly IBank[] Bank;

        public BankContext Context { get; }

        public IBank BankInfo { get; } = new BankInfo();

        public IBank Deposit { get; } = new Deposit();

        //public IBank Withdraw { get; } = new WithDraw();

        //public IBank GetLoan { get; } = new GetLoan();

        //public IBank PayLoan { get; } = new PayLoan();

        public BankManager(BoFConfig config, IReflectionHelper reflection)
        {
            this.Context = new BankContext(config, reflection);

            this.Bank = this.GetType().GetProperties().Select(prop => prop.GetValue(this)).OfType<IBank>().ToArray();

            this.OnOptionsChanged();
        }

        public void OnSaveLoaded()
        {
            foreach (IBank bank in this.Bank)
                bank.OnSaveLoaded(this.Context);
        }

        public void OnOptionsChanged()
        {
            
        }


    }
}